# CST-239

Github:
https://github.com/josephdevelops/CST-239

Screencast Video:
https://youtu.be/WktEcprW3Ow

Lucidart Diagrams:
https://lucid.app/lucidchart/cb7ec418-5328-436a-9d06-541d4bd711da/edit?invitationId=inv_3e157a81-1ce6-4d73-a8fa-fd3030ed55ec